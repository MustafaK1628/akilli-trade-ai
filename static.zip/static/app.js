const money=n=>Number(n).toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2})+' TL';
async function refresh(){const s=await (await fetch('/api/state')).json();document.getElementById('equity').textContent=money(s.equity);document.getElementById('cash').textContent=money(s.cash);document.getElementById('pnl').textContent='Toplam kâr / zarar: '+money(s.pnl);document.getElementById('pnl').style.color=s.pnl>=0?'#75e0b5':'#ff8b8b';
document.getElementById('markets').innerHTML=Object.entries(s.prices).map(([k,v])=>`<div class="market"><b>${k}</b><span>${Number(v).toLocaleString('tr-TR')}</span></div>`).join('');
document.getElementById('signals').innerHTML=s.signals.map(x=>`<div class="signal"><b>${x.symbol} · ${x.signal}</b><div class="muted">${x.reason}</div></div>`).join('');
document.getElementById('positions').innerHTML=s.positions.length?s.positions.map(p=>`<div class="position"><span>${p.symbol}<small>${p.qty} adet · ort. ${p.avg_price}</small></span><span>${money(p.value)}<small style="color:${p.pnl>=0?'#75e0b5':'#ff8b8b'}">K/Z ${money(p.pnl)}</small></span></div>`).join(''):'Henüz pozisyon yok.';
document.getElementById('trades').innerHTML=s.trades.length?s.trades.map(t=>`<div class="trade"><span>${t.symbol} · ${t.side}<small>${t.time} · ${t.qty} adet</small></span><span>${money(t.amount_tl)}<small>${t.status}</small></span></div>`).join(''):'Henüz işlem yapılmadı.'}
document.querySelectorAll('[data-side]').forEach(b=>b.addEventListener('click',async()=>{const message=document.getElementById('message');try{const r=await fetch('/api/order',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({symbol:document.getElementById('symbol').value,side:b.dataset.side,amount_tl:Number(document.getElementById('amount').value)})});const d=await r.json();if(!r.ok)throw Error(d.detail||'İşlem başarısız');message.textContent=d.message;await refresh()}catch(e){message.textContent=e.message}}));
document.getElementById('reset').addEventListener('click',async()=>{if(confirm('Sanal portföy ve işlem geçmişi silinsin mi?')){await fetch('/api/reset',{method:'POST'});await refresh()}});
refresh();
let installPrompt;
const installBtn = document.getElementById('installBtn');
window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault();
  installPrompt = event;
  if (installBtn) installBtn.hidden = false;
});
if (installBtn) installBtn.addEventListener('click', async () => {
  if (!installPrompt) return;
  installPrompt.prompt();
  await installPrompt.userChoice;
  installPrompt = null;
  installBtn.hidden = true;
});
window.addEventListener('appinstalled', () => {
  if (installBtn) installBtn.hidden = true;
});
